#pragma once
#include <dpp/fmt/core.h>
#define FMT_STRING(s) s
